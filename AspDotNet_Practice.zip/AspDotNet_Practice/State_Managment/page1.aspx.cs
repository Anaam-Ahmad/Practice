﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AspDotNet_Practice.State_Managment
{
    public partial class page1 : System.Web.UI.Page
    {
        string a = string.Empty;
        string b = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Hidden Field
            HiddenField1.Value = DateTime.Now.ToString();
            lbl1.Text = HiddenField1.Value;

            //Application State
            lbl_application.Text = Application["user"].ToString();
            if (IsPostBack == true)
            {
                lbl_application.Text = Application["Username"].ToString();
                lbl_session.Text = Session["Username"].ToString();
            }
            else
            {
                Application["Username"] = string.Empty;
                Session["Username"] = string.Empty;
            }
        }

        //Store View State
        protected void Button1_Click(object sender, EventArgs e)
        {
            ViewState["a"] = TextBox1.Text;
            ViewState["b"] = TextBox2.Text;
            TextBox1.Text = TextBox2.Text = string.Empty;
        }
        //Retrive View State
        protected void Button2_Click(object sender, EventArgs e)
        {
            if (ViewState["a"] != null)
            {
                TextBox1.Text = ViewState["a"].ToString();
            }
            if (ViewState["b"] != null)
            {
                TextBox2.Text = ViewState["b"].ToString();
            }
        }

        //Store Cookies
        protected void Button3_Click(object sender, EventArgs e)
        {
            // Non Persist Cookie
            HttpCookie userinfo = new HttpCookie("userInfo");
            userinfo["a"] = TextBox3.Text;
            userinfo["b"] = TextBox4.Text;
            userinfo.Expires.Add(new TimeSpan(0, 1, 0));
            Response.Cookies.Add(userinfo);


            // Persist Cookie
            Response.Cookies["a"].Value = TextBox3.Text;
            Response.Cookies["b"].Value = TextBox4.Text;
            TextBox3.Text = TextBox4.Text = string.Empty;
        }
        //Retrive Cookies
        protected void Button4_Click(object sender, EventArgs e)
        {
            // Non Persist Cookie
            HttpCookie reqInfo = Request.Cookies["userInfo"];
            if (reqInfo != null)
            {
                TextBox3.Text = reqInfo["a"].ToString();
                TextBox4.Text = reqInfo["b"].ToString();
            }

            // Persist Cookie
            TextBox3.Text = Request.Cookies["a"].Value;
            TextBox4.Text = Request.Cookies["b"].Value;
        }

        //Query String
        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("page2?username=" + TextBox5.Text + "&password=" + TextBox6.Text + "");
        }

        //Store Application State
        protected void Button6_Click(object sender, EventArgs e)
        {
            Application["Username"] = TextBox7.Text;
            TextBox7.Text = string.Empty;
        }
        //Retrive Application state
        protected void Button7_Click(object sender, EventArgs e)
        {
            lbl_application.Text = Application["Username"].ToString();
        }

        //Store Session State
        protected void Button8_Click(object sender, EventArgs e)
        {
            Session["Username"] = TextBox8.Text;
            TextBox8.Text = string.Empty;
        }
        //Retrive Session state
        protected void Button9_Click(object sender, EventArgs e)
        {
            lbl_session.Text = Session["Username"].ToString();
        }
    }

}