﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Asp_Crud.Models;

namespace Asp_Crud
{
    public partial class AddNew : System.Web.UI.Page
    {
        DatabaseContext db = new DatabaseContext();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void addNew_Submit_Click(object sender, EventArgs e)
        {
            Customer cust = new Customer();
            cust.Id = 0;
            cust.Customername = txtCustomerName.Text;
            cust.Locality = txtLocality.Text;
            cust.City = txtCity.Text;
            cust.State = txtState.Text;
            cust.Email = txtEmail.Text;
            cust.Telephone = txtTelephone.Text;
            cust.PhoneNumber = txtPhoneNumber.Text;
            cust.CreatedDate = DateTime.Now;
            int res = db.ExcuteQuery("insert into customerdetails values('" + cust.Customername + "','" + cust.Locality + "','" + cust.City + "','" + cust.State + "','" + cust.Email + "','" + cust.Telephone + "','" + cust.PhoneNumber + "','" + cust.CreatedDate + "');");
            if (res == 1)
            {
                Response.Redirect("/Customer.aspx");
            }
            else
            {

            }
        }
    }
}