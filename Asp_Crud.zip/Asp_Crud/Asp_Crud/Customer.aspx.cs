﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Asp_Crud.Models;
using System.Data;

namespace Asp_Crud
{
    public partial class Crud : System.Web.UI.Page
    {
        DatabaseContext db = new DatabaseContext();
        protected void Page_Load(object sender, EventArgs e)
        {
            GetCustomer();
        }

        public void GetCustomer()
        {
            DataTable dt = new DataTable();
            dt = db.RetrunDataTable("select * from customerdetails;");
            Cache.Add("CustomerDT", dt, null, System.Web.Caching.Cache.NoAbsoluteExpiration, new TimeSpan(0, 0, 60), System.Web.Caching.CacheItemPriority.Default, null);
            DataTable dt1 = (DataTable)Cache["CustomerDT"];
            CustomerGridView.DataSource = dt;
            CustomerGridView.DataBind();
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddNew.aspx");
            //Server.Transfer("AddNew.aspx");// Page Moved but page url dose not change!
        }
    }
}