﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace Asp_Crud.Models
{
    public class DatabaseContext
    {
        SqlConnection connection = new SqlConnection();
        public bool GetConnection()
        {
            bool conn = false;
            connection = new SqlConnection(ConfigurationManager.AppSettings["DefaultConnection"].ToString());
            connection.Open();
            if (connection.State == ConnectionState.Open)
            {
                conn = true;
            }
            return conn;
        }
        public int ExcuteQuery(string Query)
        {
            int res = 0;
            if (GetConnection())
            {
                SqlCommand cmd = new SqlCommand(Query,connection);
                res = cmd.ExecuteNonQuery();
            }
            return res;
        }
        public DataTable RetrunDataTable(string Query) {
            DataTable dt = new DataTable();
            if (GetConnection())
            {
                SqlCommand cmd = new SqlCommand(Query, connection);
                SqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr);
            }
            return dt;
        }
    }
}