var crypto = require('crypto');
var net = require('net');
var atob = require('atob');
var StringDecoder = require('string_decoder').StringDecoder;

// var alg = 'des-ede-cbc';
// var key = new Buffer('abcdefghijklmnop', 'utf-8');
// var iv = new Buffer('AAAAAAAAAAA=', 'base64');
// console.log('Encrypt');
// var SampleText = 'hello world';
// console.log(SampleText);
// var cipher = crypto.createCipheriv(alg, key, iv);
// var encoded = cipher.update(SampleText, 'ascii', 'base64');
// encoded += cipher.final('base64');
// console.log(encoded);

// console.log('');
// console.log('Decrypt');
// var EncryptedText = '4YdhEdx8BQF9JfaOQBKbtA==';
// var encrypted = new Buffer(EncryptedText, 'base64');
// console.log(EncryptedText);
// var decipher = crypto.createDecipheriv(alg, key, iv);
// var decoded = decipher.update(encrypted, 'binary', 'ascii');
// decoded += decipher.final('ascii');
// console.log(decoded);

// var CryptoJS = require('crypto-js');
// var base64 = require('crypto-js/enc-base64.js');
// var net = require('net');
// var atob = require('atob')

//var lib = require('./build/Release/rijndael');
//var rijndael = require('./examples/rijndael');

// var en = CryptoJS.AES.encrypt("Message",'ABCDEF');
// console.log("encry ",en.toString());
// console.log("decryencry ",CryptoJS.AES.decrypt(en.toString(),'ABCDEF').toString(CryptoJS.enc.Utf8));

// var en = CryptoJS.AES.base64.encrypt("Message",'ABCDEF');
// console.log("encry ",en.toString());
// console.log("decryencry ",CryptoJS.AES.base64.decrypt(en.toString(),'ABCDEF').toString(CryptoJS.enc.Utf8));

//var cryptkey='SysManInitialVec';
//var secretdata='ashok';
//var iv='iv';
//var iv = CryptoJS.randomBytes(16).toString('base64');
// function decode(cryptkey, iv, secretdata) {
//  var decipher = crypto.createDecipheriv('aes-256-cbc', cryptkey, iv),
//  decoded = decipher.update(secretdata);
//  decoded += decipher.final();
//  console.log('decoded ',decoded);
//  return decoded;
// }

 var client = net.connect(5000, "10.0.0.106", function () {
 console.log('connect');
 //Write data
 client.write("Iphone~");
//  client.write("uabIKdYhG0QUdP/gmI11jg==");

// buff = new byte[1024];
// iRx = soc.Receive(buff);
// chars = new char[iRx];
// d = System.Text.Encoding.UTF8.GetDecoder();
// charLen = d.GetChars(buffer, 0, iRx, chars, 0);
// recv = new System.String(chars);
// console.log(recv);

 //Read Responce
 client.on('data', function (data) {
 // var buf = Buffer.from(data,'base64').toString('ascii');
 console.log(typeof(data));
 console.log("Enter to string", data);
 console.log("buff",data.toString('utf8'));
 
 var d=atob(data);
 console.log('dataa ',d)
 var b = new Buffer(data.toString('utf8'), 'base64')
 var s = b.toString();
 client.end();
 });

//  client.on('data', function (data) {
//      console.log(data);
    // var alg = 'des-ede-cbc';
    // var key = new Buffer('abcdefghijklmnop', 'utf-8');
    // var iv = new Buffer('AAAAAAAAAAA=', 'base64');
    // var buff = new Buffer(data);
    // var buf1 = Buffer.from(buff).toString('base64');
    // console.log(buf1);
    
    // var encrypted = new Buffer(buf1, 'base64');
    // var decipher = crypto.createDecipheriv(alg, key, iv);
    // var decoded = decipher.update(encrypted, 'binary', 'ascii');
    // decoded += decipher.final('ascii');
    // console.log(decoded);

    // var buf2 = Buffer.from(buf1,'base64').toString('ascii');
    // console.log(buf2);

    // var encrypted = new Buffer(buf2, 'base64');
    // var decipher = crypto.createDecipheriv(alg, key, iv);
    // var decoded = decipher.update(encrypted, 'binary', 'ascii');
    // decoded += decipher.final('ascii');
    // console.log(decoded);


    // client.end();
    //  });

//Socket
 client.on('error', function (err) {
 console.log('error ' + err.message);
 })

 //Disconnect 
 client.on('end', function () {
 console.log('disconnected');
 })

//  client.on('connection', function (socket) {
//  console.log('connected ', socket.net);
//  console.log('connect' + socket.remoteAddress +' '+socket.remotePort);
//  })
});