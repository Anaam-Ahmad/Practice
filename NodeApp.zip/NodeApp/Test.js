function anaam(){
    
}