﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Encript_Decript;

namespace Encript_Decript
{
    public class Program
    {
        // Writen By Anaam Ahmad
       
        public static void Main(string[] args)
        {
            Program obj = new Program();
            //string plantext = "10.0.0.124";
            //string encript_val = obj.encrypt(plantext);
            //string decript_val = obj.decrypt(encript_val);
            //Console.WriteLine("Plain Text : " + plantext);
            //Console.WriteLine("Cipher Text : " + encript_val);

            CryptLib obj2 = new CryptLib("4625876");
            string val = "N14FEiDPpfZYopsv4Pd7HkXqOipVi/4xA2q/zesBR8OA+t2ofBzb9xnnFsxqt/BjAh283JCM2jcFWFdsXYv4qjkB86mhKrio/mbzVKtEDUmrNitElTLcPRNPwvss+rDrli8ibx9bcN0evrtZbV4lfhpJjMXn2FHeDR36VNoQkbwOLu4XHNjOKRPwAoyVj3AzIWxj8VrIsicxQ3LpNerTQSAHVxZIbJUw341qYQm+l8AXxPwyTLrbSYCR09JEWa+4YuOUkiEMJrnyp9/Oxc2xyVsJAgyJweJNHr8V77oXQFFJ113ehqT4HLiK+FDp9DFd8lNuHn4naLYyrTWaSMPId+pPRTvjr8VwhoHBRul4/fpnUfhzSAFy5nGDhLQHBH98KPNnNHQT5ReL+LdMF+UdkgssfFhyClj7Y9Ip34YOMsCu0hD4WOGw4ap+poPuyP1bYvWw9ZJat8DR+DaUuzX/DckzGkzXYgf7fPR7U/Invh+EXnbozTvnDLzqrRZMlNgXFgLpijADidvOAs9do8p3kbhS/7QNweLfy6SUqrpetUT6x0crUJRkitUsWStXT64pDu+95XPUxliPBf+Cq1JmG/aiH6MssuD/5gYteR4ZjlRkGF8Ec8MUO2syffDTAcyjOd6aO4aol1fJ4vz+6lKk6sIL7WPICQ0SSKR89wtkL2j5U2odixfOJJf9q25AkzCh92Y5exwJ0ArPXc9VGcen0hMIko0fNWxDR95cBFUlULg=";
            Console.WriteLine(obj2.decrypt(val));


        }
        public enum EncryptMode { ENCRYPT, DECRYPT };

        public string encrypt(string _plainText)
        {
            return encryptDecrypt(_plainText, EncryptMode.ENCRYPT);
        }

        public string decrypt(string _encryptedText)
        {
            return encryptDecrypt(_encryptedText, EncryptMode.DECRYPT);
        }
        public string encryptDecrypt(string toEncrypt, EncryptMode _mode)
        {
            var _out = "";
            UTF8Encoding _enc = new UTF8Encoding();
            string key = "abcdefghijklmnop";
            bool useHashing = false;
            byte[] keyArray;
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);
            byte[] IV = new byte[8] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }; //AAAAAAAAAAA=
            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
            }
            else
            {
                keyArray = UTF8Encoding.UTF8.GetBytes(key);
            }  
            var tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.CBC;  // which is default     
            tdes.Padding = PaddingMode.PKCS7;  // which is default
            tdes.IV = IV;
            //Console.WriteLine("iv: {0}", Convert.ToBase64String(tdes.IV));
            if (_mode.Equals(EncryptMode.ENCRYPT))
            {
                //encrypt
                ICryptoTransform cTransform = tdes.CreateEncryptor();
                byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
                _out = Convert.ToBase64String(resultArray, 0, resultArray.Length);
            }
            if (_mode.Equals(EncryptMode.DECRYPT))
            {
                //decrypt
                ICryptoTransform cTransform = tdes.CreateDecryptor();
                byte[] plainText = cTransform.TransformFinalBlock(Convert.FromBase64String(toEncrypt), 0, Convert.FromBase64String(toEncrypt).Length);
                _out = _enc.GetString(plainText);
            }
            return _out;
        }

    }
}
